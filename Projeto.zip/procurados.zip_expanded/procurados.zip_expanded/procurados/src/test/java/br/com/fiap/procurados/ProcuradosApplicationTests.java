package br.com.fiap.procurados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcuradosApplicationTests {

	@Test
	void contextLoads() {
	}

}
