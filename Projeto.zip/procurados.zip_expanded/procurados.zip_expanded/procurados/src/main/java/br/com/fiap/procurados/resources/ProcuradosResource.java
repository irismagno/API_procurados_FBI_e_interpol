package br.com.fiap.procurados.resources;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.procurados.model.Procurados;
import br.com.fiap.procurados.repository.ProcuradosRepository;

@RestController
@RequestMapping("/procurados")
public class ProcuradosResource {

    private final ProcuradosRepository procuradosRepository;

    public ProcuradosResource(ProcuradosRepository procuradosRepository) {
        this.procuradosRepository = procuradosRepository;
    }

    @GetMapping("/{nome}")
    public ResponseEntity<Object> getProcuradoPorNome(@PathVariable String nome) {
        Procurados procurado = procuradosRepository.findByNome(nome);
        if (procurado != null) {
            return ResponseEntity.ok(procurado);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Não consta como procurado na base de dados");
        }
    }
}


