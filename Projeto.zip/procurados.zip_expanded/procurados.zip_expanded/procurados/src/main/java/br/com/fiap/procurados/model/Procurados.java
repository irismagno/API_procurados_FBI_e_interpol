package br.com.fiap.procurados.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "t_procurado")
public class Procurados {
   
	@Id
	@SequenceGenerator(name="proc",sequenceName="sq_t_proc",allocationSize=1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="proc")
	@Column(name = "id")
    private Long id;
	
	@Column(name = "nome")
    private String nome;
	
	@Column(name = "genero")
    private String sexo;
	
	@Column(name = "data_de_nascimento_utilizada")
    private String dataNascimento;
	
	@Column(name = "url")
    private String url;
	
	@Column(name = "nacionalidade")
    private String nacionalidade;

    public Procurados() {
    }

    public Procurados(String nome, String sexo, String dataNascimento, String url, String nacionalidade) {
        this.nome = nome;
        this.sexo = sexo;
        this.dataNascimento = dataNascimento;
        this.url = url;
        this.nacionalidade = nacionalidade;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
    public String getNacionalidade() {
        return nacionalidade;
    }

    public void setNacionalidade(String nacionalidade) {
        this.nacionalidade = nacionalidade;
    }

	@Override
	public String toString() {
		return "Procurados [id=" + id + ", nome=" + nome + ", sexo=" + sexo + ", dataNascimento=" + dataNascimento
				+ ", url=" + url + ", nacionalidade=" + nacionalidade + "]";
	}
    
    
}
