package br.com.fiap.procurados.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.procurados.model.Procurados;

public interface ProcuradosRepository extends JpaRepository<Procurados, Long> {
    Procurados findByNome(String nome);
    List<Procurados> findByNomeContainingIgnoreCase(String nome);

}
