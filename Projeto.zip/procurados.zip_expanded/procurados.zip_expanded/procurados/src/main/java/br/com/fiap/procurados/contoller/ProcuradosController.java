package br.com.fiap.procurados.contoller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.com.fiap.procurados.model.Procurados;
import br.com.fiap.procurados.repository.ProcuradosRepository;

@Controller
public class ProcuradosController {

    private final ProcuradosRepository procuradosRepository;

    public ProcuradosController(ProcuradosRepository procuradosRepository) {
        this.procuradosRepository = procuradosRepository;
    }

    @GetMapping("/procurados")
    public String pesquisarProcurado(@RequestParam("nome") String nome, Model model) {
        List<Procurados> procurados = procuradosRepository.findByNomeContainingIgnoreCase(nome);
        model.addAttribute("procurados", procurados);
        model.addAttribute("temProcurados", !procurados.isEmpty()); // Verifica se a lista de procurados não está vazia
        return "Procurados/Procurados";
    }

    @GetMapping("/home")
    public String exibirHome(Model model) {
        model.addAttribute("temProcurados", false); // Define como false para ocultar a mensagem de "Não consta como procurado na base de dados"
        return "Procurados/Procurados";
    }
}
